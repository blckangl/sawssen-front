import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-synthese-projet-par-offre',
  templateUrl: './synthese-projet-par-offre.component.html',
  styleUrls: ['./synthese-projet-par-offre.component.scss']
})
export class SyntheseProjetParOffreComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
