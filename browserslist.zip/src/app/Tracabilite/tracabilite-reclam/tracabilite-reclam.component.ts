import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tracabilite-reclam',
  templateUrl: './tracabilite-reclam.component.html',
  styleUrls: ['./tracabilite-reclam.component.scss']
})
export class TracabiliteReclamComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
