import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tracabilite-sales',
  templateUrl: './tracabilite-sales.component.html',
  styleUrls: ['./tracabilite-sales.component.scss']
})
export class TracabiliteSalesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
