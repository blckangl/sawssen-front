import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tracabpurch',
  templateUrl: './tracabpurch.component.html',
  styleUrls: ['./tracabpurch.component.scss']
})
export class TracabpurchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
