import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-exportdevis',
  templateUrl: './exportdevis.component.html',
  styleUrls: ['./exportdevis.component.scss']
})
export class ExportdevisComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
