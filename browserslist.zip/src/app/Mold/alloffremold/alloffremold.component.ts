import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-alloffremold',
  templateUrl: './alloffremold.component.html',
  styleUrls: ['./alloffremold.component.scss']
})
export class AlloffremoldComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
