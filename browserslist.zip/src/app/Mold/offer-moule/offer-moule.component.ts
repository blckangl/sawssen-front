import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-offer-moule',
  templateUrl: './offer-moule.component.html',
  styleUrls: ['./offer-moule.component.scss']
})
export class OfferMouleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
