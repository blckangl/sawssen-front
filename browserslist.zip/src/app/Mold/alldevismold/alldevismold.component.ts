import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-alldevismold',
  templateUrl: './alldevismold.component.html',
  styleUrls: ['./alldevismold.component.scss']
})
export class AlldevismoldComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
