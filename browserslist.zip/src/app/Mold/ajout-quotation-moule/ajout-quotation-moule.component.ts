import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ajout-quotation-moule',
  templateUrl: './ajout-quotation-moule.component.html',
  styleUrls: ['./ajout-quotation-moule.component.scss']
})
export class AjoutQuotationMouleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
