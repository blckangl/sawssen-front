import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ajout-offre-moule',
  templateUrl: './ajout-offre-moule.component.html',
  styleUrls: ['./ajout-offre-moule.component.scss']
})
export class AjoutOffreMouleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
