import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quotation-moule',
  templateUrl: './quotation-moule.component.html',
  styleUrls: ['./quotation-moule.component.scss']
})
export class QuotationMouleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
