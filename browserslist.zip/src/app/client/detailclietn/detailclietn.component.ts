import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detailclietn',
  templateUrl: './detailclietn.component.html',
  styleUrls: ['./detailclietn.component.scss']
})
export class DetailclietnComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
