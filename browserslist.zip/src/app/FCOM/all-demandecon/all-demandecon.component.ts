import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-all-demandecon',
  templateUrl: './all-demandecon.component.html',
  styleUrls: ['./all-demandecon.component.scss']
})
export class AllDemandeconComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
