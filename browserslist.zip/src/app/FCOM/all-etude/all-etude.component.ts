import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-all-etude',
  templateUrl: './all-etude.component.html',
  styleUrls: ['./all-etude.component.scss']
})
export class AllEtudeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
