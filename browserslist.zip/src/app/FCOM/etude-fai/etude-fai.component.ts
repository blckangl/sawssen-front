import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-etude-fai',
  templateUrl: './etude-fai.component.html',
  styleUrls: ['./etude-fai.component.scss']
})
export class EtudeFaiComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
