import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-exquise-faisabilite-interne',
  templateUrl: './exquise-faisabilite-interne.component.html',
  styleUrls: ['./exquise-faisabilite-interne.component.scss']
})
export class ExquiseFaisabiliteInterneComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
