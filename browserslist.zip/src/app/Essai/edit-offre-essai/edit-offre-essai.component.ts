import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-offre-essai',
  templateUrl: './edit-offre-essai.component.html',
  styleUrls: ['./edit-offre-essai.component.scss']
})
export class EditOffreEssaiComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
